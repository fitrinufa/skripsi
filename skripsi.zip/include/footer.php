<footer>
  <div class="pull-right">
	Copyright&copy; by Fitri Nurul - 2018</a>
  </div>
  <div class="clearfix"></div>
</footer>