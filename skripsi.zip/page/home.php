<!-- top tiles -->
<div class="row top_tiles">
  <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
	<div class="tile-stats">
	  <div class="icon"><i class="fa fa-user"></i></div>
	  <div class="count">0</div>
	  <h3>Karyawan</h3>
	  <p>Total Seluruh Data Karyawan</p>
	</div>
  </div>
  <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
	<div class="tile-stats">
	  <div class="icon"><i class="fa fa-file-word-o"></i></div>
	  <div class="count">0</div>
	  <h3>Master 1</h3>
	  <p>Total Seluruh Data Master 1</p>
	</div>
  </div>
  <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
	<div class="tile-stats">
	  <div class="icon"><i class="fa fa-file-excel-o"></i></div>
	  <div class="count">0</div>
	  <h3>Master 2</h3>
	  <p>Total Seluruh Data Master 2</p>
	</div>
  </div>
  <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
	<div class="tile-stats">
	  <div class="icon"><i class="fa fa-file-powerpoint-o"></i></div>
	  <div class="count">0</div>
	  <h3>Master 3</h3>
	  <p>Total Seluruh Data Master 3</p>
	</div>
  </div>
</div>          
<!-- /top tiles -->

<!-- /page content -->
<div class="clearfix"></div>
<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<h2>Dashboard</h2>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<h1>Selamat Datang, <?php echo ucfirst($_SESSION['fullname']);?></h1>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
		<br/>
	  </div>
	</div>
  </div>
</div>